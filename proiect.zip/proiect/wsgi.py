from device_availability.webserver_device_swt import app

if __name__ == "__main__":
    app.run()
